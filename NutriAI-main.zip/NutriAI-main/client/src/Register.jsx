import React, {useState, useContext} from 'react'
import {AuthContext} from './AuthContext'

export default function Register({onSuccess}){
  const {register} = useContext(AuthContext)
  const [username,setUsername] = useState('')
  const [password,setPassword] = useState('')
  const [err,setErr] = useState(null)

  async function submit(e){
    e.preventDefault()
    const res = await register(username,password)
    if(res.error) {
      setErr(res.error)
    } else {
      setErr(null)
      onSuccess?.()
    }
  }

  return (
    <form onSubmit={submit} className="auth-form">
      <h3>Регистрация</h3>
      {err && <div className="error">{err}</div>}
      <input placeholder="Логин" value={username} onChange={e=>setUsername(e.target.value)} />
      <input placeholder="Пароль" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button type="submit">Зарегистрироваться</button>
    </form>
  )
}
