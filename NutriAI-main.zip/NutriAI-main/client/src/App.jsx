import React, { useEffect, useMemo, useState } from 'react'

const FOOD_DB = {
  'яблоко': { kcal: 52, protein: 0.3, carbs: 14, fat: 0.2 },
  'банан': { kcal: 89, protein: 1.1, carbs: 23, fat: 0.3 },
  'апельсин': { kcal: 47, protein: 0.9, carbs: 12, fat: 0.1 },
  'груша': { kcal: 57, protein: 0.4, carbs: 15, fat: 0.1 },
  'виноград': { kcal: 69, protein: 0.7, carbs: 18, fat: 0.2 },
  'куриная грудка': { kcal: 165, protein: 31, carbs: 0, fat: 3.6 },
  'курица варёная': { kcal: 137, protein: 29, carbs: 0, fat: 1.9 },
  'говядина': { kcal: 250, protein: 26, carbs: 0, fat: 17 },
  'свинина': { kcal: 242, protein: 27, carbs: 0, fat: 14 },
  'лосось': { kcal: 208, protein: 20, carbs: 0, fat: 13 },
  'тунец': { kcal: 132, protein: 28, carbs: 0, fat: 1 },
  'яйцо': { kcal: 155, protein: 13, carbs: 1.1, fat: 11 },
  'творог 5%': { kcal: 121, protein: 17, carbs: 3, fat: 5 },
  'творог обезжиренный': { kcal: 71, protein: 16, carbs: 1.3, fat: 0.6 },
  'йогурт натуральный': { kcal: 66, protein: 5, carbs: 8, fat: 3.3 },
  'молоко': { kcal: 52, protein: 2.8, carbs: 4.7, fat: 2.5 },
  'сыр': { kcal: 363, protein: 26, carbs: 0.5, fat: 29 },
  'рис варёный': { kcal: 130, protein: 2.7, carbs: 28, fat: 0.3 },
  'гречка варёная': { kcal: 110, protein: 4, carbs: 21, fat: 1.1 },
  'овсянка': { kcal: 88, protein: 3, carbs: 15, fat: 1.7 },
  'макароны варёные': { kcal: 131, protein: 5, carbs: 25, fat: 1.1 },
  'картофель варёный': { kcal: 82, protein: 2, carbs: 17, fat: 0.1 },
  'картофель фри': { kcal: 312, protein: 3.4, carbs: 41, fat: 15 },
  'хлеб белый': { kcal: 265, protein: 9, carbs: 49, fat: 3.2 },
  'хлеб ржаной': { kcal: 174, protein: 6.6, carbs: 34, fat: 1.2 },
  'авокадо': { kcal: 160, protein: 2, carbs: 9, fat: 15 },
  'орехи грецкие': { kcal: 654, protein: 15, carbs: 14, fat: 65 },
  'миндаль': { kcal: 579, protein: 21, carbs: 22, fat: 50 },
  'арахис': { kcal: 567, protein: 26, carbs: 16, fat: 49 },
  'оливковое масло': { kcal: 884, protein: 0, carbs: 0, fat: 100 },
  'сливочное масло': { kcal: 717, protein: 0.9, carbs: 0.1, fat: 81 },
  'мёд': { kcal: 304, protein: 0.3, carbs: 82, fat: 0 },
  'сахар': { kcal: 387, protein: 0, carbs: 100, fat: 0 },
  'шоколад молочный': { kcal: 535, protein: 7.7, carbs: 59, fat: 30 },
  'брокколи': { kcal: 34, protein: 2.8, carbs: 7, fat: 0.4 },
  'помидор': { kcal: 18, protein: 0.9, carbs: 3.9, fat: 0.2 },
  'огурец': { kcal: 15, protein: 0.7, carbs: 3.6, fat: 0.1 },
  'морковь': { kcal: 41, protein: 0.9, carbs: 10, fat: 0.2 },
  'капуста': { kcal: 25, protein: 1.3, carbs: 6, fat: 0.1 },
  'лук репчатый': { kcal: 40, protein: 1.1, carbs: 9, fat: 0.1 },
  'чечевица варёная': { kcal: 116, protein: 9, carbs: 20, fat: 0.4 },
  'фасоль варёная': { kcal: 127, protein: 8.7, carbs: 23, fat: 0.5 },
  'нут варёный': { kcal: 164, protein: 9, carbs: 27, fat: 2.6 },
  'креветки': { kcal: 99, protein: 24, carbs: 0.2, fat: 0.3 },
  'кефир': { kcal: 53, protein: 3, carbs: 4, fat: 2.5 },
  'сметана': { kcal: 206, protein: 2.8, carbs: 3.2, fat: 20 },
  'яблочный сок': { kcal: 46, protein: 0.1, carbs: 11, fat: 0.1 },
  'пицца': { kcal: 266, protein: 11, carbs: 33, fat: 10 },
  'бургер': { kcal: 295, protein: 17, carbs: 24, fat: 15 },
  'суши': { kcal: 150, protein: 6, carbs: 23, fat: 3.5 },
  'пельмени': { kcal: 250, protein: 12, carbs: 30, fat: 10 },
  'вареники': { kcal: 220, protein: 7, carbs: 32, fat: 7 },
  'борщ': { kcal: 70, protein: 3, carbs: 10, fat: 2 },
  'щи': { kcal: 40, protein: 2, carbs: 6, fat: 1 },
  'куриный бульон': { kcal: 15, protein: 1.5, carbs: 0.5, fat: 0.5 },
  'оливковая паста': { kcal: 120, protein: 1, carbs: 1, fat: 13 },
  'греческий салат': { kcal: 140, protein: 4, carbs: 6, fat: 11 },
  'салат оливье': { kcal: 180, protein: 4, carbs: 12, fat: 12 },
  'капуста квашеная': { kcal: 19, protein: 1, carbs: 4, fat: 0 },
  'печенье': { kcal: 480, protein: 6, carbs: 68, fat: 22 },
  'чипсы': { kcal: 536, protein: 6.6, carbs: 53, fat: 34 },
  'шашлык': { kcal: 220, protein: 22, carbs: 1, fat: 14 },
  'картофельное пюре': { kcal: 110, protein: 2.5, carbs: 18, fat: 3.5 },
  'лапша': { kcal: 138, protein: 5, carbs: 25, fat: 2 },
  'рис басмати': { kcal: 130, protein: 2.5, carbs: 28.5, fat: 0.3 },
  'рис жасмин': { kcal: 129, protein: 2.8, carbs: 28, fat: 0.3 },
  'перловка': { kcal: 123, protein: 3.4, carbs: 27, fat: 1.1 },
  'пшено': { kcal: 119, protein: 3.5, carbs: 23, fat: 1.1 },
  'кукуруза варёная': { kcal: 96, protein: 3.4, carbs: 21, fat: 1.5 },
  'тыква запеченная': { kcal: 26, protein: 1, carbs: 7, fat: 0.1 },
  'баклажан жареный': { kcal: 120, protein: 2.1, carbs: 10, fat: 8 },
  'кабачок тушёный': { kcal: 35, protein: 1.2, carbs: 6, fat: 0.2 },
  'грибы шампиньоны': { kcal: 22, protein: 3.1, carbs: 3.3, fat: 0.3 },
  'фасоль красная': { kcal: 127, protein: 8.7, carbs: 23, fat: 0.5 },
  'горох сушёный': { kcal: 340, protein: 21, carbs: 60, fat: 1.5 },
  'соевый соус': { kcal: 53, protein: 8, carbs: 4.9, fat: 0.6 },
  'майонез': { kcal: 680, protein: 1, carbs: 1, fat: 75 },
  'кетчуп': { kcal: 112, protein: 1.5, carbs: 25, fat: 0.1 },
  'горчица': { kcal: 66, protein: 4, carbs: 5, fat: 4.7 },
  'мёд цветочный': { kcal: 304, protein: 0.3, carbs: 82, fat: 0 },
  'клубника': { kcal: 32, protein: 0.7, carbs: 7.7, fat: 0.3 },
  'малина': { kcal: 52, protein: 1.2, carbs: 12, fat: 0.7 },
  'черника': { kcal: 57, protein: 0.7, carbs: 14, fat: 0.3 },
  'манго': { kcal: 60, protein: 0.8, carbs: 15, fat: 0.4 },
  'ананас': { kcal: 50, protein: 0.5, carbs: 13, fat: 0.1 },
  'киви': { kcal: 61, protein: 1.1, carbs: 15, fat: 0.5 },
  'авокадо тост': { kcal: 250, protein: 6, carbs: 20, fat: 16 },
  'окрошка': { kcal: 70, protein: 4, carbs: 6, fat: 3 },
  'сайра консервированная': { kcal: 136, protein: 18, carbs: 0, fat: 6.5 },
  'сардина консервированная': { kcal: 185, protein: 24, carbs: 0, fat: 9 },
  'икра красная': { kcal: 196, protein: 29, carbs: 0, fat: 9 },
  'икра чёрная': { kcal: 264, protein: 25, carbs: 4, fat: 17 },
  'молочный коктейль': { kcal: 140, protein: 5, carbs: 20, fat: 3 },
  'коктейль протеиновый': { kcal: 120, protein: 24, carbs: 3, fat: 1.5 },
  'творожный десерт': { kcal: 170, protein: 9, carbs: 16, fat: 7 },
  'омлет': { kcal: 154, protein: 11, carbs: 2, fat: 11 },
  'яйца вареные': { kcal: 155, protein: 13, carbs: 1.1, fat: 11 },
  'куриная ножка': { kcal: 215, protein: 26, carbs: 0, fat: 11 },
  'индейка': { kcal: 135, protein: 29, carbs: 0, fat: 1.5 },
  'филе индейки': { kcal: 135, protein: 29, carbs: 0, fat: 1.5 },
  'телятина': { kcal: 143, protein: 20, carbs: 0, fat: 7 },
  'говяжий стейк': { kcal: 271, protein: 25, carbs: 0, fat: 18 },
  'сосиска': { kcal: 301, protein: 12, carbs: 2.1, fat: 27 },
  'колбаса варёная': { kcal: 265, protein: 12, carbs: 2, fat: 22 },
  'колбаса сырокопченая': { kcal: 430, protein: 24, carbs: 1.5, fat: 36 },
  'сало': { kcal: 900, protein: 1.7, carbs: 0, fat: 100 },
  'гречневая каша': { kcal: 110, protein: 4, carbs: 21, fat: 1.1 },
  'овсяная каша': { kcal: 68, protein: 2.5, carbs: 12, fat: 1.5 },
  'рисовая каша': { kcal: 115, protein: 2.1, carbs: 23, fat: 1.1 },
  'сок апельсиновый': { kcal: 45, protein: 0.7, carbs: 10.4, fat: 0.2 },
  'сок яблочный': { kcal: 46, protein: 0.1, carbs: 11, fat: 0.1 },
}

const WEEKDAYS_RU = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб']
const RING_CIRC = 2 * Math.PI * 82
const GOAL_KEY = 'calorie-goal'
const CUSTOM_FOODS_KEY = 'custom-foods'
const PROFILE_KEY = 'user-profile'
const AUTH_KEY = 'user-auth'
const DAY_KEY_PREFIX = 'foodlog:'

function getTodayKey(){
  return new Date().toISOString().slice(0,10)
}

function getWeekDates(today = new Date()){
  const dates = []
  const start = new Date(today)
  start.setDate(today.getDate() - today.getDay())
  for(let i = 0; i < 7; i++){
    const d = new Date(start)
    d.setDate(start.getDate() + i)
    dates.push(d)
  }
  return dates
}

function capitalize(text){
  if(!text) return ''
  return text.charAt(0).toUpperCase() + text.slice(1)
}

export default function App(){
  const [activeDay, setActiveDay] = useState(new Date())
  const activeDayKey = useMemo(() => activeDay.toISOString().slice(0,10), [activeDay])
  const todayKey = useMemo(() => new Date().toISOString().slice(0,10), [])
  const [goal, setGoal] = useState(2000)
  const [entries, setEntries] = useState([])
  const [customFoods, setCustomFoods] = useState({})
  const [auth, setAuth] = useState({ login: '', password: '', email: '', nickname: '' })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [authSaved, setAuthSaved] = useState(false)
  const [profile, setProfile] = useState({ weight: '', height: '', age: '' })
  const [profileSaved, setProfileSaved] = useState(false)
  const [step, setStep] = useState(1)
  const [pageTransition, setPageTransition] = useState('enter')
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [foodName, setFoodName] = useState('')
  const [foodGrams, setFoodGrams] = useState('')
  const [showManual, setShowManual] = useState(false)
  const [manualKcal, setManualKcal] = useState('')
  const [manualProtein, setManualProtein] = useState('')
  const [manualCarbs, setManualCarbs] = useState('')
  const [manualFat, setManualFat] = useState('')
  const [rememberFood, setRememberFood] = useState(true)

  useEffect(() => {
    const savedGoal = Number(localStorage.getItem(GOAL_KEY) || '') || 2000
    setGoal(savedGoal)

    const savedEntries = localStorage.getItem(DAY_KEY_PREFIX + activeDayKey)
    if(savedEntries){
      try { setEntries(JSON.parse(savedEntries)) } catch (err) { setEntries([]) }
    } else {
      setEntries([])
    }

    const savedCustom = localStorage.getItem(CUSTOM_FOODS_KEY)
    if(savedCustom){
      try { setCustomFoods(JSON.parse(savedCustom)) } catch (err) { setCustomFoods({}) }
    }
  }, [activeDayKey])

  useEffect(() => {
    let savedAuthValid = false
    let savedProfileValid = false

    const savedAuth = localStorage.getItem(AUTH_KEY)
    if(savedAuth){
      try {
        const parsed = JSON.parse(savedAuth)
        if(parsed.login && parsed.password && parsed.nickname && parsed.email){
          setAuth({ login: parsed.login, password: '', email: parsed.email, nickname: parsed.nickname })
          savedAuthValid = true
        }
      } catch (err) {
        setAuth({ login: '', password: '', email: '', nickname: '' })
      }
    }

    const savedProfile = localStorage.getItem(PROFILE_KEY)
    if(savedProfile){
      try {
        const parsed = JSON.parse(savedProfile)
        if(Number(parsed.weight) > 0 && Number(parsed.height) > 0 && Number(parsed.age) > 0){
          setProfile(parsed)
          savedProfileValid = true
        }
      } catch (err) {
        setProfile({ weight: '', height: '', age: '' })
      }
    }

    setAuthSaved(savedAuthValid)
    setProfileSaved(savedProfileValid)
    setStep(1)
  }, [])

  useEffect(() => {
    localStorage.setItem(DAY_KEY_PREFIX + activeDayKey, JSON.stringify(entries))
  }, [entries, activeDayKey])

  useEffect(() => {
    localStorage.setItem(GOAL_KEY, String(goal))
  }, [goal])

  useEffect(() => {
    localStorage.setItem(CUSTOM_FOODS_KEY, JSON.stringify(customFoods))
  }, [customFoods])

  const profileComplete = Number(profile.weight) > 0 && Number(profile.height) > 0 && Number(profile.age) > 0
  const authComplete = auth.login.trim() && auth.password.trim() && auth.nickname.trim() && auth.email.trim() && auth.password === confirmPassword
  const profileGoal = useMemo(() => {
    if(!profileComplete) return 2000
    return Math.round(Number(profile.weight) * 24)
  }, [profileComplete, profile.weight])

  const profileNutrition = useMemo(() => {
    if(!profileComplete) return null
    const weight = Number(profile.weight)
    const kcal = Math.round(weight * 24)
    const protein = Math.round(weight * 1.8)
    const fat = Math.round(weight * 0.8)
    const carbs = Math.max(0, Math.round((kcal - protein * 4 - fat * 9) / 4))
    return { kcal, protein, carbs, fat }
  }, [profile, profileComplete])

  const allFoods = useMemo(() => {
    return [...Object.keys(FOOD_DB), ...Object.keys(customFoods)]
  }, [customFoods])

  const normalizedFoodName = foodName.trim().toLowerCase()
  const foundFood = useMemo(() => {
    if(!normalizedFoodName) return null
    if(customFoods[normalizedFoodName]) return customFoods[normalizedFoodName]
    if(FOOD_DB[normalizedFoodName]) return FOOD_DB[normalizedFoodName]
    const partial = allFoods.find(key => key.includes(normalizedFoodName) || normalizedFoodName.includes(key))
    return partial ? (customFoods[partial] || FOOD_DB[partial]) : null
  }, [normalizedFoodName, allFoods, customFoods])

  useEffect(() => {
    if(foundFood){
      setShowManual(false)
    }
  }, [foundFood])

  const grams = Number(foodGrams)
  const previewText = useMemo(() => {
    if(!foodName.trim()) return { text: '', type: '' }
    if(foundFood && grams > 0){
      const kcal = Math.round(foundFood.kcal * grams / 100)
      const protein = Math.round(foundFood.protein * grams / 100 * 10) / 10
      const carbs = Math.round(foundFood.carbs * grams / 100 * 10) / 10
      const fat = Math.round(foundFood.fat * grams / 100 * 10) / 10
      return { text: `≈ ${kcal} ккал · Б ${protein} · У ${carbs} · Ж ${fat}`, type: 'found' }
    }
    if(foundFood){
      return { text: 'Продукт найден — укажите граммы', type: 'found' }
    }
    return { text: 'Такого продукта нет в базе — можно ввести КБЖУ вручную ниже', type: 'missing' }
  }, [foundFood, grams, foodName])

  function resetForm(){
    setFoodName('')
    setFoodGrams('')
    setManualKcal('')
    setManualProtein('')
    setManualCarbs('')
    setManualFat('')
    setShowManual(false)
  }

  function addEntry(){
    const name = foodName.trim()
    if(!name) return
    if(!grams || grams <= 0) return
    if(!foundFood){
      setShowManual(true)
      return
    }

    const item = {
      name: capitalize(name),
      kcal: Math.round(foundFood.kcal * grams / 100),
      protein: Math.round(foundFood.protein * grams / 100 * 10) / 10,
      carbs: Math.round(foundFood.carbs * grams / 100 * 10) / 10,
      fat: Math.round(foundFood.fat * grams / 100 * 10) / 10,
    }

    setEntries(prev => [...prev, item])
    resetForm()
  }

  function addManualEntry(){
    const name = foodName.trim()
    if(!name) return
    if(!grams || grams <= 0) return
    const kcal = Number(manualKcal)
    if(!kcal || kcal <= 0) return

    const protein = Number(manualProtein) || 0
    const carbs = Number(manualCarbs) || 0
    const fat = Number(manualFat) || 0

    const item = {
      name: capitalize(name),
      kcal: Math.round(kcal),
      protein: Math.round(protein * 10) / 10,
      carbs: Math.round(carbs * 10) / 10,
      fat: Math.round(fat * 10) / 10,
    }

    setEntries(prev => [...prev, item])

    if(rememberFood){
      const key = name.toLowerCase()
      const factor = 100 / grams
      setCustomFoods(prev => ({
        ...prev,
        [key]: {
          kcal: Math.round(kcal * factor * 10) / 10,
          protein: Math.round(protein * factor * 10) / 10,
          carbs: Math.round(carbs * factor * 10) / 10,
          fat: Math.round(fat * factor * 10) / 10,
        }
      }))
    }

    resetForm()
  }

  function deleteEntry(index){
    setEntries(prev => prev.filter((_, idx) => idx !== index))
  }

  function changeDay(delta){
    setActiveDay(prev => {
      const next = new Date(prev)
      next.setDate(prev.getDate() + delta)
      return next
    })
  }

  function clearDay(){
    if(!entries.length) return
    if(window.confirm('Удалить все записи за выбранный день?')){
      setEntries([])
      localStorage.removeItem(DAY_KEY_PREFIX + activeDayKey)
    }
  }

  function saveProfile(){
    if(!profileComplete){
      alert('Укажите вес, рост и возраст правильными числами.')
      return
    }
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile))
    if(authComplete){
      localStorage.setItem(AUTH_KEY, JSON.stringify(auth))
    }
    setProfileSaved(true)
    setIsTransitioning(true)
    setPageTransition('exit')
    setTimeout(() => {
      setStep(3)
      setPageTransition('enter')
      setIsTransitioning(false)
    }, 300)
    if(!Number(localStorage.getItem(GOAL_KEY))){
      setGoal(profileNutrition?.kcal || profileGoal)
    }
  }

  function deleteProfile(){
    if(!window.confirm('Удалить профиль и создать новый аккаунт?')) return
    if(isTransitioning) return
    setIsTransitioning(true)
    setPageTransition('exit')
    setTimeout(() => {
      localStorage.removeItem(AUTH_KEY)
      localStorage.removeItem(PROFILE_KEY)
      localStorage.removeItem(GOAL_KEY)
      setAuth({ login: '', password: '', email: '', nickname: '' })
      setConfirmPassword('')
      setAuthSaved(false)
      setProfile({ weight: '', height: '', age: '' })
      setProfileSaved(false)
      setGoal(2000)
      setStep(5)
      setPageTransition('enter')
      setIsTransitioning(false)
    }, 300)
  }

  function animateStepChange(targetStep){
    if(isTransitioning) return
    setIsTransitioning(true)
    setPageTransition('exit')
    setTimeout(() => {
      setStep(targetStep)
      setPageTransition('enter')
      setIsTransitioning(false)
    }, 300)
  }

  function saveAuth(){
    if(!auth.login.trim() || !auth.password.trim() || !auth.nickname.trim() || !auth.email.trim()){
      alert('Заполните все поля аккаунта.')
      return
    }
    if(auth.password !== confirmPassword){
      alert('Пароли не совпадают.')
      return
    }
    localStorage.setItem(AUTH_KEY, JSON.stringify(auth))
    setAuthSaved(true)
    setIsTransitioning(true)
    setPageTransition('exit')
    setTimeout(() => {
      setStep(2)
      setPageTransition('enter')
      setIsTransitioning(false)
    }, 300)
  }

  function attemptLogin(){
    if(!auth.login.trim() || !auth.password.trim()){
      alert('Введите логин или email и пароль.')
      return
    }
    const savedAuth = localStorage.getItem(AUTH_KEY)
    if(!savedAuth){
      alert('Аккаунт не найден. Зарегистрируйтесь.')
      return
    }
    try {
      const parsed = JSON.parse(savedAuth)
      const loginMatch = auth.login.trim().toLowerCase()
      const validLogin = parsed.login.toLowerCase() === loginMatch || parsed.email.toLowerCase() === loginMatch
      if(!validLogin || parsed.password !== auth.password){
        alert('Неверный логин или пароль.')
        return
      }
      setAuth(parsed)
      setAuthSaved(true)
      const nextStep = profileSaved ? 3 : 2
      setIsTransitioning(true)
      setPageTransition('exit')
      setTimeout(() => {
        setStep(nextStep)
        setPageTransition('enter')
        setIsTransitioning(false)
      }, 300)
    } catch (err) {
      alert('Ошибка учетных данных. Попробуйте снова.')
    }
  }

  const weekDates = useMemo(() => getWeekDates(activeDay), [activeDay])

  const weekTotals = useMemo(() => {
    const today = activeDayKey
    const totals = {}
    weekDates.forEach(d => {
      const key = d.toISOString().slice(0,10)
      if(key === today) return
      const raw = localStorage.getItem(DAY_KEY_PREFIX + key)
      const items = raw ? JSON.parse(raw) : []
      totals[key] = items.reduce((sum, item) => sum + (Number(item.kcal) || 0), 0)
    })
    return totals
  }, [activeDayKey, weekDates])

  const totals = useMemo(() => {
    return entries.reduce((acc, item) => {
      acc.kcal += Number(item.kcal) || 0
      acc.protein += Number(item.protein) || 0
      acc.carbs += Number(item.carbs) || 0
      acc.fat += Number(item.fat) || 0
      return acc
    }, { kcal: 0, protein: 0, carbs: 0, fat: 0 })
  }, [entries])

  const effectiveGoal = profileNutrition ? profileNutrition.kcal : goal
  const isProfileMode = Boolean(profileNutrition)

  const targets = useMemo(() => {
    if(profileNutrition){
      return {
        protein: profileNutrition.protein,
        carbs: profileNutrition.carbs,
        fat: profileNutrition.fat,
      }
    }
    return {
      protein: Math.round(effectiveGoal * 0.30 / 4),
      carbs: Math.round(effectiveGoal * 0.45 / 4),
      fat: Math.round(effectiveGoal * 0.25 / 9),
    }
  }, [effectiveGoal, profileNutrition])

  const ringPercent = effectiveGoal > 0 ? Math.round(totals.kcal / effectiveGoal * 100) : 0
  const ringOffset = RING_CIRC * (1 - Math.min(100, ringPercent) / 100)
  const ringColor = ringPercent > 100
    ? '#ff3d7f'
    : ringPercent >= 50
      ? '#ff5a1f'
      : (() => {
          const t = ringPercent / 50
          const start = { r: 174, g: 232, b: 58 }
          const end = { r: 255, g: 90, b: 31 }
          const r = Math.round(start.r + (end.r - start.r) * t)
          const g = Math.round(start.g + (end.g - start.g) * t)
          const b = Math.round(start.b + (end.b - start.b) * t)
          return `rgb(${r}, ${g}, ${b})`
        })()

  const dateBadge = new Intl.DateTimeFormat('ru-RU', { day:'2-digit', month:'long', weekday:'short' }).format(activeDay)

  useEffect(() => {
    if(profileNutrition && !localStorage.getItem(GOAL_KEY)){
      setGoal(profileNutrition.kcal)
    }
  }, [profileNutrition])

  if(step === 1){
    return (
      <div className={`auth-screen page-${pageTransition}`}>
        <div className="auth-card auth-card-login">
          <div className="auth-header auth-header-login">
            <h1>Welcome back</h1>
            <p>Sign in to continue tracking your nutrition with NutriAI.</p>
          </div>

          <form className="auth-form auth-form-login" onSubmit={e => { e.preventDefault(); attemptLogin() }}>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="login">Login or email</label>
                <input
                  type="text"
                  id="login"
                  placeholder="username or email"
                  autoComplete="username"
                  value={auth.login}
                  onChange={e => setAuth(prev => ({ ...prev, login: e.target.value }))}
                  autoFocus
                />
              </div>
            </div>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="password">Password</label>
                <input
                  type="password"
                  id="password"
                  placeholder="********"
                  autoComplete="current-password"
                  value={auth.password}
                  onChange={e => setAuth(prev => ({ ...prev, password: e.target.value }))}
                />
              </div>
            </div>

            <button type="submit" className="btn-add btn-auth btn-login">Sign in</button>
            <button
              type="button"
              className="back-to-login"
              onClick={() => {
                setAuth({ login: '', password: '', email: '', nickname: '' })
                setConfirmPassword('')
                animateStepChange(5)
              }}
            >
              Create new account
            </button>
          </form>
        </div>
      </div>
    )
  }

  if(step === 5){
    return (
      <div className={`auth-screen page-${pageTransition}`}>
        <div className="auth-card auth-card-register">
          <div className="auth-header auth-header-register">
            <h1>Create account</h1>
            <p>Start tracking your calories with a fast, stylish onboarding flow.</p>
          </div>

          <form className="auth-form auth-form-register" onSubmit={e => { e.preventDefault(); saveAuth() }}>
            <button type="button" className="google-btn">
              <span className="google-icon">G</span>
              Sign up with Google
            </button>
            <div className="separator"><span>or</span></div>
            <div className="step-dots">
              <span className="dot active" />
              <span className="dot" />
              <span className="dot" />
            </div>

            <div className="section-title">Account details</div>

            <div className="field-row">
              <div>
                <label className="mini" htmlFor="login">Username (min. 6 characters)</label>
                <input
                  type="text"
                  id="login"
                  placeholder="your_username"
                  autoComplete="username"
                  value={auth.login}
                  onChange={e => setAuth(prev => ({ ...prev, login: e.target.value }))}
                  autoFocus
                />
              </div>
            </div>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="nickname">Nickname</label>
                <input
                  type="text"
                  id="nickname"
                  placeholder="display name"
                  autoComplete="name"
                  value={auth.nickname}
                  onChange={e => setAuth(prev => ({ ...prev, nickname: e.target.value }))}
                />
              </div>
            </div>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  placeholder="you@email.com"
                  autoComplete="email"
                  value={auth.email}
                  onChange={e => setAuth(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
            </div>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="password">Password (8+ chars, 1 uppercase, 1 number)</label>
                <input
                  type="password"
                  id="password"
                  placeholder="********"
                  autoComplete="new-password"
                  value={auth.password}
                  onChange={e => setAuth(prev => ({ ...prev, password: e.target.value }))}
                />
              </div>
            </div>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="confirmPassword">Confirm password</label>
                <input
                  type="password"
                  id="confirmPassword"
                  placeholder="********"
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                />
              </div>
            </div>

            <button type="submit" className="btn-add btn-auth btn-register">Continue →</button>
            <button
              type="button"
              className="back-to-login"
              onClick={() => {
                setConfirmPassword('')
                setAuth(prev => ({ ...prev, password: '' }))
                animateStepChange(1)
              }}
            >
              Back to login
            </button>
          </form>
        </div>
      </div>
    )
  }

  if(step === 2){
    return (
      <div className={`wrap page-${pageTransition}`}>
        <header className="top">
          <div className="header-left">
            <div className="brand"><span className="logo">NutriAI</span></div>
            <div className="date-badge">Привет, {auth.nickname || 'друг'}!</div>
          </div>
        </header>

        <div className="profile-card">
          <p className="panel-title">Укажите параметры</p>
          <div className="add-card">
            <p className="manual-note">Вес, рост и возраст нужны, чтобы приложение могло подстроиться под вас и предложить цель.</p>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="weight">Вес, кг</label>
                <input type="number" id="weight" min="1" value={profile.weight} onChange={e => setProfile(prev => ({ ...prev, weight: e.target.value }))} />
              </div>
              <div>
                <label className="mini" htmlFor="height">Рост, см</label>
                <input type="number" id="height" min="1" value={profile.height} onChange={e => setProfile(prev => ({ ...prev, height: e.target.value }))} />
              </div>
              <div>
                <label className="mini" htmlFor="age">Возраст</label>
                <input type="number" id="age" min="1" value={profile.age} onChange={e => setProfile(prev => ({ ...prev, age: e.target.value }))} />
              </div>
            </div>
            {profileNutrition && (
              <div className="preview-line found">
                Ваша норма: {profileNutrition.kcal} ккал, Б {profileNutrition.protein}г, У {profileNutrition.carbs}г, Ж {profileNutrition.fat}г
              </div>
            )}
            <button className="btn-add" onClick={saveProfile}>Сохранить параметры</button>
          </div>
        </div>
      </div>
    )
  }

  if(step === 4){
    return (
      <div className={`wrap page-${pageTransition}`}>
        <header className="top">
          <div className="header-left">
            <div className="brand"><span className="logo">NutriAI</span></div>
            <div className="date-badge">Профиль</div>
          </div>
          <div className="header-right">
            <button className="link-btn back-button" type="button" onClick={() => animateStepChange(3)}>← Назад</button>
          </div>
        </header>

        <div className="profile-card">
          <p className="panel-title">Ваш профиль</p>
          <div className="add-card">
            <p className="manual-note">Здесь можно изменить параметры и увидеть регистрационные данные.</p>
            <div className="profile-summary" style={{ marginBottom: '18px' }}>
              <div className="profile-summary-title">Данные аккаунта</div>
              <div className="profile-summary-values">
                <span>Никнейм: {auth.nickname || '—'}</span>
                <span>Логин: {auth.login || '—'}</span>
                <span>Возраст: {profile.age || '—'} лет</span>
                <span>Вес: {profile.weight || '—'} кг</span>
                <span>Рост: {profile.height || '—'} см</span>
                <span>Цель: {effectiveGoal} ккал</span>
                {profileNutrition && (
                  <span>Норма: {profileNutrition.kcal} ккал, Б {profileNutrition.protein}г, У {profileNutrition.carbs}г, Ж {profileNutrition.fat}г</span>
                )}
              </div>
            </div>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="nickname">Никнейм</label>
                <input type="text" id="nickname" value={auth.nickname} onChange={e => setAuth(prev => ({ ...prev, nickname: e.target.value }))} />
              </div>
              <div>
                <label className="mini" htmlFor="login">Логин</label>
                <input type="text" id="login" value={auth.login} onChange={e => setAuth(prev => ({ ...prev, login: e.target.value }))} />
              </div>
            </div>
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="weight">Вес, кг</label>
                <input type="number" id="weight" min="1" value={profile.weight} onChange={e => setProfile(prev => ({ ...prev, weight: e.target.value }))} />
              </div>
              <div>
                <label className="mini" htmlFor="height">Рост, см</label>
                <input type="number" id="height" min="1" value={profile.height} onChange={e => setProfile(prev => ({ ...prev, height: e.target.value }))} />
              </div>
              <div>
                <label className="mini" htmlFor="age">Возраст</label>
                <input type="number" id="age" min="1" value={profile.age} onChange={e => setProfile(prev => ({ ...prev, age: e.target.value }))} />
              </div>
            </div>
            {profileNutrition && (
              <div className="preview-line found">
                Ваша норма: {profileNutrition.kcal} ккал, Б {profileNutrition.protein}г, У {profileNutrition.carbs}г, Ж {profileNutrition.fat}г
              </div>
            )}
            <button className="btn-add" onClick={saveProfile}>Сохранить профиль</button>
            <button className="btn-add btn-danger" onClick={deleteProfile}>Удалить профиль</button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={`wrap page-${pageTransition}`}>
      <header className="top">
        <div className="header-left">
          <div className="brand"><span className="logo">NutriAI</span></div>
          <div className="date-badge">{dateBadge}</div>
        </div>
        <div className="header-right">
          <button className="link-btn profile-link" type="button" onClick={() => animateStepChange(4)}>
            Профиль
          </button>
        </div>
      </header>

      <div className="grid">
        <div>
          <p className="panel-title">Добавить приём пищи</p>
          <div className="add-card">
            <div className="field-row">
              <div>
                <label className="mini" htmlFor="foodName">Продукт</label>
                <input
                  type="text"
                  id="foodName"
                  placeholder="Начните вводить: курица, рис..."
                  list="foodDatalist"
                  autoComplete="off"
                  value={foodName}
                  onChange={e => setFoodName(e.target.value)}
                />
                <datalist id="foodDatalist">
                  {allFoods.map(name => <option key={name} value={capitalize(name)} />)}
                </datalist>
              </div>
              <div>
                <label className="mini" htmlFor="foodGrams">Порция, г</label>
                <input
                  type="number"
                  id="foodGrams"
                  min="0"
                  placeholder="100"
                  value={foodGrams}
                  onChange={e => setFoodGrams(e.target.value)}
                />
              </div>
            </div>
            <div className={`preview-line ${previewText.type}`}>{previewText.text}</div>
            <button className="btn-add" onClick={addEntry}>Добавить в дневник</button>

            <div className={`manual-panel ${showManual ? 'show' : ''}`}>
              <p className="manual-note">Такого продукта нет в базе — впишите КБЖУ вручную для этой порции, и в следующий раз он найдётся сам.</p>
              <div className="macro-row">
                <div>
                  <label className="mini" htmlFor="manKcal">Ккал</label>
                  <input type="number" id="manKcal" min="0" placeholder="0" value={manualKcal} onChange={e => setManualKcal(e.target.value)} />
                </div>
                <div>
                  <label className="mini" htmlFor="manProtein">Белки, г</label>
                  <input type="number" id="manProtein" min="0" placeholder="0" value={manualProtein} onChange={e => setManualProtein(e.target.value)} />
                </div>
                <div>
                  <label className="mini" htmlFor="manCarbs">Углеводы, г</label>
                  <input type="number" id="manCarbs" min="0" placeholder="0" value={manualCarbs} onChange={e => setManualCarbs(e.target.value)} />
                </div>
              </div>
              <div className="field-row">
                <div>
                  <label className="mini" htmlFor="manFat">Жиры, г</label>
                  <input type="number" id="manFat" min="0" placeholder="0" value={manualFat} onChange={e => setManualFat(e.target.value)} />
                </div>
                <div className="remember-row">
                  <label className="mini remember-label">
                    <input type="checkbox" checked={rememberFood} onChange={e => setRememberFood(e.target.checked)} /> запомнить продукт
                  </label>
                </div>
              </div>
              <button className="btn-add btn-manual" onClick={addManualEntry}>Добавить эту порцию</button>
            </div>
          </div>

          <p className="panel-title">Сегодня съедено</p>
          <ul className="log-list">
            {entries.map((item, idx) => (
              <li key={idx} className="log-item">
                <div>
                  <div className="name">{item.name}</div>
                  {(item.protein || item.carbs || item.fat) && (
                    <div className="macros">
                      {item.protein ? `Б ${item.protein}г` : ''}
                      {item.carbs ? `${item.protein ? ' · ' : ''}У ${item.carbs}г` : ''}
                      {item.fat ? `${item.protein || item.carbs ? ' · ' : ''}Ж ${item.fat}г` : ''}
                    </div>
                  )}
                </div>
                <div className="right">
                  <span className="kcal">{item.kcal} ккал</span>
                  <button className="del-btn" onClick={() => deleteEntry(idx)}>×</button>
                </div>
              </li>
            ))}
          </ul>
          {!entries.length && <div className="empty-state">Пока пусто — добавьте первый приём пищи</div>}

          <div className="day-actions">
            <button className="link-btn" onClick={() => changeDay(-1)}>Предыдущий день</button>
            <button className="link-btn" onClick={() => changeDay(1)}>Следующий день</button>
            <button className="link-btn" onClick={clearDay}>Очистить текущий день</button>
          </div>
        </div>

        <div className="facts">
          <div className="week-strip">
            {weekDates.map(d => {
              const key = d.toISOString().slice(0,10)
              const isSelected = key === activeDayKey
              const total = isSelected ? totals.kcal : weekTotals[key]
              const cls = !isSelected ? (total > effectiveGoal ? 'over' : 'under') : ''
              return (
                <div key={key} className={`day-cell${isSelected ? ' today' : ''}`} onClick={() => setActiveDay(new Date(d))}>
                  <div className="day-name">{WEEKDAYS_RU[d.getDay()]}</div>
                  <div className="day-number">{d.getDate()}</div>
                  <div className={`day-kcal ${cls}`}>{isSelected ? (total > 0 ? total : <span className="day-dot" />) : total}</div>
                </div>
              )
            })}
          </div>

          <div className="goal-line">
            {isProfileMode ? (
              <span>Цель по профилю: {profileNutrition.kcal} ккал</span>
            ) : (
              <span>Цель = <input type="number" id="goalInput" min="0" value={goal} onChange={e => setGoal(Number(e.target.value) || 0)} /> ккал</span>
            )}
            {isProfileMode && <div className="goal-hint">Изменить калорийность можно только после изменения параметров профиля.</div>}
          </div>

          <div className="ring-wrap">
            <svg viewBox="0 0 190 190">
              <circle className="ring-track" cx="95" cy="95" r="82"></circle>
              <circle className="ring-progress" cx="95" cy="95" r="82" strokeDasharray={RING_CIRC} strokeDashoffset={ringOffset} style={{ stroke: ringColor }} />
            </svg>
            <div className="ring-center">
              <div className="ring-kcal">{totals.kcal}</div>
              <div className="ring-label">калорий съедено</div>
              <div className="ring-remaining">{effectiveGoal - totals.kcal >= 0 ? `Осталось: ${effectiveGoal - totals.kcal} ккал` : `Перебор: ${Math.abs(effectiveGoal - totals.kcal)} ккал`}</div>
            </div>
          </div>

          <div className="macro-bars">
            <div className="macro-bar-row">
              <div className="macro-bar-top">
                <span>Углеводы</span>
                <span className="val">{Math.round(totals.carbs)} / {targets.carbs} г</span>
              </div>
              <div className="macro-bar-track"><div className="macro-bar-fill" style={{ width: targets.carbs ? `${Math.min(100, totals.carbs / targets.carbs * 100)}%` : '0%', background: 'var(--lime)' }} /></div>
            </div>
            <div className="macro-bar-row">
              <div className="macro-bar-top">
                <span>Белки</span>
                <span className="val">{Math.round(totals.protein)} / {targets.protein} г</span>
              </div>
              <div className="macro-bar-track"><div className="macro-bar-fill" style={{ width: targets.protein ? `${Math.min(100, totals.protein / targets.protein * 100)}%` : '0%', background: 'var(--blue)' }} /></div>
            </div>
            <div className="macro-bar-row">
              <div className="macro-bar-top">
                <span>Жиры</span>
                <span className="val">{Math.round(totals.fat)} / {targets.fat} г</span>
              </div>
              <div className="macro-bar-track"><div className="macro-bar-fill" style={{ width: targets.fat ? `${Math.min(100, totals.fat / targets.fat * 100)}%` : '0%', background: 'var(--orange)' }} /></div>
            </div>
          </div>

          <div className="bottom-row">
            <span className="added-pill">Добавлено: {entries.length}</span>
            <button className="fab-add" type="button" onClick={() => document.getElementById('foodName').focus()}>+</button>
          </div>

          <p className="footnote">Данные сохраняются в этом браузере отдельно на каждый день. Изменение цели применяется сразу.</p>
        </div>
      </div>

      <footer className="credit">Личный дневник питания · данные приватны и хранятся только у вас</footer>
    </div>
  )
}
