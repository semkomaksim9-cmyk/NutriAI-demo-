import React, {useState, useEffect, useContext} from 'react'
import {AuthContext} from './AuthContext'

export default function Profile({cart, setCart}){
  const {token} = useContext(AuthContext)
  const [name, setName] = useState('')
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(false)

  async function load(){
    setLoading(true)
    const res = await fetch('/api/meals', {headers: {Authorization: token ? `Bearer ${token}` : ''}})
    const data = await res.json()
    setHistory(data)
    setLoading(false)
  }

  useEffect(()=>{ if(token) load() }, [token])

  async function save(){
    const res = await fetch('/api/meals', {
      method: 'POST', headers: {'Content-Type':'application/json', Authorization: token ? `Bearer ${token}` : ''},
      body: JSON.stringify({name, items: cart})
    })
    const data = await res.json()
    if(data.id){ setName(''); setCart([]); load() }
  }

  async function deleteMeal(id){
    if(!confirm('Удалить приём?')) return
    const res = await fetch(`/api/meals/${id}`, {method: 'DELETE', headers:{Authorization: token ? `Bearer ${token}` : ''}})
    const data = await res.json()
    if(data.deleted) load()
  }

  async function editMeal(id, oldName){
    const newName = prompt('Новое название приёма', oldName)
    if(newName == null) return
    const res = await fetch(`/api/meals/${id}`, {
      method: 'PUT', headers: {'Content-Type':'application/json', Authorization: token ? `Bearer ${token}` : ''},
      body: JSON.stringify({name: newName})
    })
    const data = await res.json()
    if(data.updated) load()
  }

  function restoreMeal(items){
    setCart(items)
  }

  return (
    <div>
      <h2>Профиль и история</h2>
      <div>
        <input placeholder="Название приёма (завтрак)" value={name} onChange={e=>setName(e.target.value)} />
        <button onClick={save} disabled={!cart.length}>Сохранить приём</button>
      </div>
      <h3>История</h3>
      {loading ? <div>Загрузка...</div> : (
        <ul>
          {history.map(h=> (
            <li key={h.id} style={{marginBottom:12}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <div>
                  <b>{h.name}</b> — {new Date(h.created_at).toLocaleString()}
                </div>
                <div>
                  <button onClick={()=>restoreMeal(h.items)} style={{marginRight:6}}>Восстановить</button>
                  <button onClick={()=>editMeal(h.id, h.name)} style={{marginRight:6}}>Переименовать</button>
                  <button onClick={()=>deleteMeal(h.id)}>Удалить</button>
                </div>
              </div>
              <ul>
                {h.items.map((it,idx)=> <li key={idx}>{it.name} — {it.grams || 100} г</li>)}
              </ul>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
