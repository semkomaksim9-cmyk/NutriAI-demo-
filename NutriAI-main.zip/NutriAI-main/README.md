# NutriAI
Проект: сайт для подсчёта калорий (React + Node/Express + SQLite).

Запуск:

- Сервер:

```bash
cd server
npm install
node index.js
```

- Фронтенд (в другом терминале):

```bash
cd client
npm install
npm run dev
```

API:
- `POST /api/register` — регистрация
- `POST /api/login` — вход, возвращает JWT
- `GET /api/products?q=` — поиск продуктов
- `POST /api/calc` — подсчёт калорий по списку продуктов

Импорт продуктов из CSV (опционально):

1. Подготовьте CSV с заголовком `id,name,calories_per_100`.
2. Выполните в каталоге `server`:

```bash
npm run import-products
```

По умолчанию импорт берёт `server/products.csv`, можно указать путь: `node import_products.js ./path/to/file.csv`.

