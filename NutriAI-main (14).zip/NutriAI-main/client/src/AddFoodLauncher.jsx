import React, { useEffect, useState } from 'react'
import { Camera, Search, Barcode, Pencil, Clock, Star, X, Sparkles } from 'lucide-react'

const ANIMATION_MS = 260

function vibrate(pattern){
  try{
    if(typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(pattern)
  }catch{}
}

export default function AddFoodLauncher({ open, mealLabel, onClose, onSelect, t }){
  const [mounted, setMounted] = useState(false)
  const [closing, setClosing] = useState(false)

  useEffect(() => {
    if(open){
      setMounted(true)
      setClosing(false)
      vibrate(8)
    } else if(mounted){
      setClosing(true)
      const timer = setTimeout(() => {
        setMounted(false)
        setClosing(false)
      }, ANIMATION_MS)
      return () => clearTimeout(timer)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  if(!mounted) return null

  // Fixed order: AI Scan is always the emphasized primary action.
  const OPTIONS = [
    { key: 'photo', Icon: Camera, title: t('option_photo_title'), desc: t('option_photo_desc'), primary: true },
    { key: 'barcode', Icon: Barcode, title: t('option_barcode_title'), desc: t('option_barcode_desc') },
    { key: 'search', Icon: Search, title: t('option_search_title'), desc: t('option_search_desc') },
    { key: 'favorites', Icon: Star, title: t('option_favorite_title'), desc: t('option_favorite_desc') },
    { key: 'recent', Icon: Clock, title: t('option_recent_title'), desc: t('option_recent_desc') },
    { key: 'manual', Icon: Pencil, title: t('option_manual_title'), desc: t('option_manual_desc') },
  ]

  function handleSelect(key){
    vibrate(12)
    onSelect(key)
  }

  return (
    <div className={`npl-overlay ${closing ? 'closing' : ''}`} onClick={onClose}>
      <div className={`npl-sheet ${closing ? 'closing' : ''}`} onClick={e => e.stopPropagation()}>
        <div className="npl-handle" />
        <div className="npl-header">
          <div className="npl-title">{t('add_to')} {mealLabel}</div>
          <button type="button" className="npl-close" onClick={onClose} aria-label="Close">
            <X size={16} />
          </button>
        </div>

        <div className="npl-grid">
          {OPTIONS.map((opt, i) => (
            <button
              key={opt.key}
              type="button"
              className={`npl-card np-tactile ${opt.primary ? 'npl-card-large' : ''}`}
              style={{ animationDelay: `${i * 0.05}s` }}
              onClick={() => handleSelect(opt.key)}
            >
              {opt.primary && (
                <div className="npl-card-badge"><Sparkles size={11} /> {t('ai_primary_badge')}</div>
              )}
              <div className="npl-card-icon">
                <opt.Icon size={opt.primary ? 24 : 19} color={opt.primary ? '#04140F' : '#00C98D'} strokeWidth={1.8} />
              </div>
              <div className="npl-card-text">
                <div className="npl-card-title">{opt.title}</div>
                <div className="npl-card-desc">{opt.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
